﻿#region XAML window definition
$xaml = @'
<Window
   xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
   xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
   MinWidth="200"
   Width ="Auto"
   SizeToContent="WidthAndHeight"
   Title="Cloudistics Ad-Hoc Windows NFS Management"
   Topmost="False">
    <Grid Margin="10,40,10,10">
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="Auto"/>
            <ColumnDefinition Width="*"/>
        </Grid.ColumnDefinitions>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
        </Grid.RowDefinitions>
        
        <TextBlock Grid.Column="0" Grid.Row="0" Grid.ColumnSpan="2" Margin="5">Windows NFS Management Details:</TextBlock>
        <TextBlock Grid.Column="0" Grid.Row="1" Margin="5">NFS Features</TextBlock>
        <TextBlock Grid.Column="0" Grid.Row="3" Margin="5">NFS Exports</TextBlock>
        <TextBlock Grid.Column="0" Grid.Row="5" Margin="5">NFS Shares</TextBlock>
        
        <ListView Grid.Column="1" Grid.Row="1" Name="view_Feature">
            <ListView.View>
                <GridView >
                    <GridViewColumn Header="Install">
                        <GridViewColumn.CellTemplate>
                            <DataTemplate>
                                <CheckBox IsChecked="{Binding Installed}" />
                            </DataTemplate> 
                        </GridViewColumn.CellTemplate>
                    </GridViewColumn>
                    <GridViewColumn Width="Auto" Header="Name" DisplayMemberBinding="{Binding Name}"/>
                    <GridViewColumn Width="Auto" Header="Display Name" DisplayMemberBinding="{Binding DisplayName}"/>
                    <GridViewColumn Width="Auto" Header="Current State" DisplayMemberBinding="{Binding CurrentState}"/>               
                </GridView>
            </ListView.View>
        </ListView>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Grid.Column="1" Grid.Row="2"  Margin="0,10,0,0">
            <Button Name="btn_AddWindowsFeatures" MinWidth="80" Height="22" Margin="5">Add/Remove NFS Features</Button>
        </StackPanel>

        <ListView Grid.Column="1" Grid.Row="3" Name="view_Export">
            <ListView.View>
                <GridView>
                <GridViewColumn Header="Remove">
                        <GridViewColumn.CellTemplate>
                            <DataTemplate>
                                <CheckBox IsChecked="{Binding Remove}" />
                            </DataTemplate> 
                        </GridViewColumn.CellTemplate>
                    </GridViewColumn>
                    <GridViewColumn Width="Auto" Header="Name" DisplayMemberBinding="{Binding Name}"/> 
                    <GridViewColumn Width="Auto" Header="Path" DisplayMemberBinding="{Binding Path}"/>
                    <GridViewColumn Width="Auto" Header="IsOnLine" DisplayMemberBinding="{Binding IsOnline}"/>
                     <GridViewColumn Width="Auto" Header="Unmapped User Access" DisplayMemberBinding="{Binding unmappedUserAccess}"/>
                     <GridViewColumn Width="Auto" Header="Server" DisplayMemberBinding="{Binding NetworkName}"/>
                </GridView>
            </ListView.View>
        </ListView>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Grid.Column="1" Grid.Row="4"  Margin="0,10,0,0">
            <Button Name="btn_AddNfsExport" MinWidth="80" Height="22" Margin="5">Add NFS Export</Button>
            <Button Name="btn_RemoveNfsExport" MinWidth="80" Height="22" Margin="5">Remove NFS Export</Button>
        </StackPanel>

        <ListView Grid.Column="1" Grid.Row="5" Name="view_Share">
            <ListView.View>
                <GridView>
                    <GridViewColumn Header="Remove">
                        <GridViewColumn.CellTemplate>
                            <DataTemplate>
                                <CheckBox IsChecked="{Binding Remove}" />
                            </DataTemplate> 
                        </GridViewColumn.CellTemplate>
                    </GridViewColumn>
                    <GridViewColumn Width="Auto" Header="Name" DisplayMemberBinding="{Binding Name}"/>
                    <GridViewColumn Width="Auto" Header="Provider Name" DisplayMemberBinding="{Binding ProviderName}"/>
                    <GridViewColumn Width="Auto" Header="File System" DisplayMemberBinding="{Binding filesystem}"/>
                </GridView>
            </ListView.View>
        </ListView>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Grid.Column="1" Grid.Row="6"  Margin="0,10,0,0">
            <Button Name="btn_addNfsShare" MinWidth="80" Height="22" Margin="5">Add NFS Share</Button>
            <Button Name="btn_removeNfsShare" MinWidth="80" Height="22" Margin="5">Remove NFS Share</Button>
        </StackPanel>

        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,10,0,0" Grid.Row="7" Grid.ColumnSpan="2">
            <TextBlock Name="lbl_prerequisites" Margin="5">Prerequisites</TextBlock>
            <Button Name="btn_Exit" MinWidth="80" Height="22" Margin="5">Exit</Button>
        </StackPanel>
    </Grid>
</Window>
'@
#endregion

#region encodedstuff
function set-xnfsshare{

$x='IAAkAHgAYQBtAGwAIAA9ACAAQAAnACAAPABXAGkAbgBkAG8AdwAgACAAeABtAGwAbgBzAD0AJwBoAHQAdABwADoALwAvAHMAYwBoAGUAbQBhAHMALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AdwBpAG4AZgB4AC8AMgAwADAANgAvAHgAYQBtAGwALwBwAHIAZQBzAGUAbgB0AGEAdABpAG8AbgAnACAAIAB4AG0AbABuAHMAOgB4AD0AJwBoAHQAdABwADoALwAvAHMAYwBoAGUAbQBhAHMALgBtAGkAYwByAG8AcwBvAGYAdAAuAGMAbwBtAC8AdwBpAG4AZgB4AC8AMgAwADAANgAvAHgAYQBtAGwAJwAgACAATQBpAG4AVwBpAGQAdABoAD0AIgAzADAAIgAgACAAVwBpAGQAdABoACAAPQAiAEEAdQB0AG8AIgAgACAAUwBpAHoAZQBUAG8AQwBvAG4AdABlAG4AdAA9ACIAVwBpAGQAdABoAEEAbgBkAEgAZQBpAGcAaAB0ACIAIAAgAFQAaQB0AGwAZQA9ACcATQBvAHUAbgB0ACAAbgBmAHMAIABFAHgAcABvAHIAdAAnACAAIABUAG8AcABtAG8AcwB0AD0AIgBUAHIAdQBlACIAIAAgAD4AIAAgACAAIAAgACAAIAAgACAAPABHAHIAaQBkAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AEcAcgBpAGQALgBSAG8AdwBEAGUAZgBpAG4AaQB0AGkAbwBuAHMAPgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwAUgBvAHcARABlAGYAaQBuAGkAdABpAG8AbgAgAEgAZQBpAGcAaAB0AD0AIgBBAHUAdABvACIAIAAvAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AFIAbwB3AEQAZQBmAGkAbgBpAHQAaQBvAG4AIABIAGUAaQBnAGgAdAA9ACIAQQB1AHQAbwAiACAALwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AFIAbwB3AEQAZQBmAGkAbgBpAHQAaQBvAG4AIABIAGUAaQBnAGgAdAA9ACIAQQB1AHQAbwAiACAALwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AFIAbwB3AEQAZQBmAGkAbgBpAHQAaQBvAG4AIABIAGUAaQBnAGgAdAA9ACIAQQB1AHQAbwAiACAALwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPAAvAEcAcgBpAGQALgBSAG8AdwBEAGUAZgBpAG4AaQB0AGkAbwBuAHMAPgAgACAAIAAgACAAIAAgACAAIAA8AEcAcgBpAGQALgBDAG8AbAB1AG0AbgBEAGUAZgBpAG4AaQB0AGkAbwBuAHMAPgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwAQwBvAGwAdQBtAG4ARABlAGYAaQBuAGkAdABpAG8AbgAgAFcAaQBkAHQAaAA9ACIAQQB1AHQAbwAiACAALwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPABDAG8AbAB1AG0AbgBEAGUAZgBpAG4AaQB0AGkAbwBuACAAVwBpAGQAdABoAD0AIgBBAHUAdABvACIAIAAvAD4AIAAgACAAIAAgACAAIAAgACAAPAAvAEcAcgBpAGQALgBDAG8AbAB1AG0AbgBEAGUAZgBpAG4AaQB0AGkAbwBuAHMAPgAgACAAIAAgACAAIAAgACAAIAA8AFQAZQB4AHQAQgBsAG8AYwBrACAATQBhAHIAZwBpAG4APQAiADUAIgAgAEcAcgBpAGQALgBSAG8AdwA9ACIAMAAiACAARwByAGkAZAAuAEMAbwBsAHUAbQBuAD0AIgAwACIAPgBuAGYAcwAgAFMAZQByAHYAZQByADoAPAAvAFQAZQB4AHQAQgBsAG8AYwBrAD4AIAAgACAAIAAgACAAIAAgACAAPABUAGUAeAB0AEIAbABvAGMAawAgAE0AYQByAGcAaQBuAD0AIgA1ACIAIABHAHIAaQBkAC4AUgBvAHcAPQAiADEAIgAgAEcAcgBpAGQALgBDAG8AbAB1AG0AbgA9ACIAMAAiAD4AUwBlAGwAZQBjAHQAIABuAGYAcwAgAEUAeABwAG8AcgB0ADoAPAAvAFQAZQB4AHQAQgBsAG8AYwBrAD4AIAAgACAAIAAgACAAIAAgACAAPABUAGUAeAB0AEIAbABvAGMAawAgAE0AYQByAGcAaQBuAD0AIgA1ACIAIABHAHIAaQBkAC4AUgBvAHcAPQAiADIAIgAgAEcAcgBpAGQALgBDAG8AbAB1AG0AbgA9ACIAMAAiAD4AbgBmAHMAIABTAGgAYQByAGUAOgA8AC8AVABlAHgAdABCAGwAbwBjAGsAPgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwAUwB0AGEAYwBrAFAAYQBuAGUAbAAgAE8AcgBpAGUAbgB0AGEAdABpAG8AbgA9ACIASABvAHIAaQB6AG8AbgB0AGEAbAAiACAARwByAGkAZAAuAFIAbwB3AD0AIgAwACIAIABHAHIAaQBkAC4AQwBvAGwAdQBtAG4APQAiADEAIgAgAEgAbwByAGkAegBvAG4AdABhAGwAQQBsAGkAZwBuAG0AZQBuAHQAPQAiAEwAZQBmAHQAIgA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPABUAGUAeAB0AEIAbwB4ACAATgBhAG0AZQA9ACIAdAB4AHQAXwBzAGUAcgB2AGUAcgBOAGEAbQBlACIAIABNAGEAcgBnAGkAbgA9ACIANQAiACAAVwBpAGQAdABoAD0AIgAyADUAMAAiACAASABlAGkAZwBoAHQAPQAiADIAMgAiACAALwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPABCAHUAdAB0AG8AbgAgAE4AYQBtAGUAPQAnAGIAdABuAF8AYwBoAGUAYwBrAE4AZgBzAFMAaABhAHIAZQBzACcAIABIAG8AcgBpAHoAbwBuAHQAYQBsAEEAbABpAGcAbgBtAGUAbgB0AD0AIgBMAGUAZgB0ACIAIABNAGkAbgBXAGkAZAB0AGgAPQAiADgAMAAiACAATQBhAHIAZwBpAG4APQAiADMAIgAgAEMAbwBuAHQAZQBuAHQAPQAiAEYAaQBuAGQAIABuAGYAcwAgAFMAaABhAHIAZQBzACIAIAAvAD4AIAAgACAAIAAgACAAIAAgACAAPAAvAFMAdABhAGMAawBQAGEAbgBlAGwAPgAgACAAIAAgACAAIAAgACAAIAAgADwATABpAHMAdABWAGkAZQB3ACAARwByAGkAZAAuAFIAbwB3AD0AIgAxACIAIABHAHIAaQBkAC4AQwBvAGwAdQBtAG4APQAiADEAIgAgAE4AYQBtAGUAPQAiAFYAaQBlAHcAMQAiACAATQBhAHIAZwBpAG4APQAiADUAIgA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AEwAaQBzAHQAVgBpAGUAdwAuAFYAaQBlAHcAPgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AEcAcgBpAGQAVgBpAGUAdwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwARwByAGkAZABWAGkAZQB3AEMAbwBsAHUAbQBuACAASABlAGEAZABlAHIAPQAiAE0AbwB1AG4AdAAiAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AEcAcgBpAGQAVgBpAGUAdwBDAG8AbAB1AG0AbgAuAEMAZQBsAGwAVABlAG0AcABsAGEAdABlAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwARABhAHQAYQBUAGUAbQBwAGwAYQB0AGUAPgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AFIAYQBkAGkAbwBCAHUAdAB0AG8AbgAgAEkAcwBDAGgAZQBjAGsAZQBkAD0AIgB7AEIAaQBuAGQAaQBuAGcAIABNAG8AdQBuAHQAfQAiACAARwByAG8AdQBwAE4AYQBtAGUAPQAiAGMAaABvAGkAYwBlACIAIAAvAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwALwBEAGEAdABhAFQAZQBtAHAAbABhAHQAZQA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPAAvAEcAcgBpAGQAVgBpAGUAdwBDAG8AbAB1AG0AbgAuAEMAZQBsAGwAVABlAG0AcABsAGEAdABlAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPAAvAEcAcgBpAGQAVgBpAGUAdwBDAG8AbAB1AG0AbgA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPABHAHIAaQBkAFYAaQBlAHcAQwBvAGwAdQBtAG4AIABXAGkAZAB0AGgAPQAiAEEAdQB0AG8AIgAgAEgAZQBhAGQAZQByAD0AIgBOAGEAbQBlACIAIABEAGkAcwBwAGwAYQB5AE0AZQBtAGIAZQByAEIAaQBuAGQAaQBuAGcAPQAiAHsAQgBpAG4AZABpAG4AZwAgAE4AYQBtAGUAfQAiAC8APgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AEcAcgBpAGQAVgBpAGUAdwBDAG8AbAB1AG0AbgAgAFcAaQBkAHQAaAA9ACIAQQB1AHQAbwAiACAASABlAGEAZABlAHIAPQAiAFAAYQB0AGgAIgAgAEQAaQBzAHAAbABhAHkATQBlAG0AYgBlAHIAQgBpAG4AZABpAG4AZwA9ACIAewBCAGkAbgBkAGkAbgBnACAAUABhAHQAaAB9ACIALwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwARwByAGkAZABWAGkAZQB3AEMAbwBsAHUAbQBuACAAVwBpAGQAdABoAD0AIgBBAHUAdABvACIAIABIAGUAYQBkAGUAcgA9ACIAUABTAEMAbwBtAHAAdQB0AGUAcgBuAGEAbQBlACIAIABEAGkAcwBwAGwAYQB5AE0AZQBtAGIAZQByAEIAaQBuAGQAaQBuAGcAPQAiAHsAQgBpAG4AZABpAG4AZwAgAFAAUwBDAG8AbQBwAHUAdABlAHIAbgBhAG0AZQB9ACIALwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AC8ARwByAGkAZABWAGkAZQB3AD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwALwBMAGkAcwB0AFYAaQBlAHcALgBWAGkAZQB3AD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AC8ATABpAHMAdABWAGkAZQB3AD4AIAAgACAAIAAgACAAIAAgACAAPABTAHQAYQBjAGsAUABhAG4AZQBsACAATwByAGkAZQBuAHQAYQB0AGkAbwBuAD0AIgBIAG8AcgBpAHoAbwBuAHQAYQBsACIAIABHAHIAaQBkAC4AUgBvAHcAPQAiADIAIgAgAEcAcgBpAGQALgBDAG8AbAB1AG0AbgA9ACIAMQAiACAASABvAHIAaQB6AG8AbgB0AGEAbABBAGwAaQBnAG4AbQBlAG4AdAA9ACIATABlAGYAdAAiAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AFQAZQB4AHQAQgBvAHgAIABOAGEAbQBlAD0AIgB0AHgAdABfAGUAeABwAG8AcgB0AE4AYQBtAGUAIgAgAE0AYQByAGcAaQBuAD0AIgA1ACIAIABXAGkAZAB0AGgAPQAiADIANQAwACIAIABIAGUAaQBnAGgAdAA9ACIAMgAyACIAIAAvAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAA8AEIAdQB0AHQAbwBuACAATgBhAG0AZQA9ACcAYgB0AG4AXwBnAGUAdABzAGgAYQByAGUAJwAgAEgAbwByAGkAegBvAG4AdABhAGwAQQBsAGkAZwBuAG0AZQBuAHQAPQAiAEwAZQBmAHQAIgAgAE0AaQBuAFcAaQBkAHQAaAA9ACIAOAAwACIAIABNAGEAcgBnAGkAbgA9ACIAMwAiACAAQwBvAG4AdABlAG4AdAA9ACIARwBlAHQAIABTAGUAbABlAGMAdABlAGQAIABuAGYAcwAgAFMAaABhAHIAZQAiACAALwA+ACAAIAAgACAAIAAgACAAIAAgADwALwBTAHQAYQBjAGsAUABhAG4AZQBsAD4AIAAgACAAIAAgACAAIAAgACAAPABTAHQAYQBjAGsAUABhAG4AZQBsACAATwByAGkAZQBuAHQAYQB0AGkAbwBuAD0AIgBIAG8AcgBpAHoAbwBuAHQAYQBsACIAIABHAHIAaQBkAC4AUgBvAHcAPQAiADMAIgAgAEcAcgBpAGQALgBDAG8AbAB1AG0AbgA9ACIAMQAiACAASABvAHIAaQB6AG8AbgB0AGEAbABBAGwAaQBnAG4AbQBlAG4AdAA9ACIAUgBpAGcAaAB0ACIAPgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPABCAHUAdAB0AG8AbgAgAE4AYQBtAGUAPQAnAGIAdABuAF8AbQBvAHUAbgB0AEUAeABwAG8AcgB0ACcAIABIAG8AcgBpAHoAbwBuAHQAYQBsAEEAbABpAGcAbgBtAGUAbgB0AD0AIgBSAGkAZwBoAHQAIgAgAE0AaQBuAFcAaQBkAHQAaAA9ACIAOAAwACIAIABNAGEAcgBnAGkAbgA9ACIAMwAiACAAQwBvAG4AdABlAG4AdAA9ACIATQBvAHUAbgB0ACIAIAAvAD4AIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwAQgB1AHQAdABvAG4AIABOAGEAbQBlAD0AJwBiAHQAbgBfAGMAbABvAHMAZQAnACAASABvAHIAaQB6AG8AbgB0AGEAbABBAGwAaQBnAG4AbQBlAG4AdAA9ACIAUgBpAGcAaAB0ACIAIABNAGkAbgBXAGkAZAB0AGgAPQAiADgAMAAiACAATQBhAHIAZwBpAG4APQAiADMAIgAgAEMAbwBuAHQAZQBuAHQAPQAiAEMAbABvAHMAZQAiACAALwA+ACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAPAAvAFMAdABhAGMAawBQAGEAbgBlAGwAPgAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgADwALwBHAHIAaQBkAD4AIAA8AC8AVwBpAG4AZABvAHcAPgAgACcAQAAgACAAZgB1AG4AYwB0AGkAbwBuACAAQwBvAG4AdgBlAHIAdAAtAFgAQQBNAEwAdABvAFcAaQBuAGQAbwB3ACAAewAgACAAIAAgACAAcABhAHIAYQBtACAAIAAgACAAIAAoACAAIAAgACAAIAAgACAAIAAgAFsAUABhAHIAYQBtAGUAdABlAHIAKABNAGEAbgBkAGEAdABvAHIAeQA9ACQAdAByAHUAZQApAF0AIAAgACAAIAAgACAAIAAgACAAWwBzAHQAcgBpAG4AZwBdACAAIAAgACAAIAAgACAAIAAgACQAWABBAE0ATAAgACAAIAAgACAAKQAgACAAIAAgACAAIAAgACAAIAAgAEEAZABkAC0AVAB5AHAAZQAgAC0AQQBzAHMAZQBtAGIAbAB5AE4AYQBtAGUAIABQAHIAZQBzAGUAbgB0AGEAdABpAG8AbgBGAHIAYQBtAGUAdwBvAHIAawAgACAAIAAgACAAIAAgACAAIAAgACQAcgBlAGEAZABlAHIAIAA9ACAAWwBYAE0ATAAuAFgATQBMAFIAZQBhAGQAZQByAF0AOgA6AEMAcgBlAGEAdABlACgAWwBJAE8ALgBTAHQAcgBpAG4AZwBSAGUAYQBkAGUAcgBdACQAWABBAE0ATAApACAAIAAgACAAIAAkAHIAZQBzAHUAbAB0ACAAPQAgAFsAVwBpAG4AZABvAHcAcwAuAE0AYQByAGsAdQBwAC4AWABBAE0ATABSAGUAYQBkAGUAcgBdADoAOgBMAG8AYQBkACgAJAByAGUAYQBkAGUAcgApACAAIAAgACAAIAAkAHIAZQBhAGQAZQByAC4AQwBsAG8AcwBlACgAKQAgACAAIAAgACAAJAByAGUAYQBkAGUAcgAgAD0AIABbAFgATQBMAC4AWABNAEwAUgBlAGEAZABlAHIAXQA6ADoAQwByAGUAYQB0AGUAKABbAEkATwAuAFMAdAByAGkAbgBnAFIAZQBhAGQAZQByAF0AJABYAEEATQBMACkAIAAgACAAIAAgAHcAaABpAGwAZQAgACgAJAByAGUAYQBkAGUAcgAuAFIAZQBhAGQAKAApACkAIAAgACAAIAAgAHsAIAAgACAAIAAgACAAIAAgACAAJABuAGEAbQBlAD0AJAByAGUAYQBkAGUAcgAuAEcAZQB0AEEAdAB0AHIAaQBiAHUAdABlACgAJwBOAGEAbQBlACcAKQAgACAAIAAgACAAIAAgACAAIABpAGYAIAAoACEAJABuAGEAbQBlACkAIAB7ACAAJABuAGEAbQBlAD0AJAByAGUAYQBkAGUAcgAuAEcAZQB0AEEAdAB0AHIAaQBiAHUAdABlACgAJwB4ADoATgBhAG0AZQAnACkAIAB9ACAAIAAgACAAIAAgACAAIAAgAGkAZgAoACQAbgBhAG0AZQApACAAIAAgACAAIAAgACAAIAAgAHsAJAByAGUAcwB1AGwAdAAgAHwAIABBAGQAZAAtAE0AZQBtAGIAZQByACAATgBvAHQAZQBQAHIAbwBwAGUAcgB0AHkAIAAtAE4AYQBtAGUAIAAkAG4AYQBtAGUAIAAtAFYAYQBsAHUAZQAgACQAcgBlAHMAdQBsAHQALgBGAGkAbgBkAE4AYQBtAGUAKAAkAG4AYQBtAGUAKQAgAC0ARgBvAHIAYwBlAH0AIAAgACAAIAAgAH0AIAAgACAAIAAgACQAcgBlAGEAZABlAHIALgBDAGwAbwBzAGUAKAApACAAIAAgACAAIAAkAHIAZQBzAHUAbAB0ACAAfQAgACAAIABmAHUAbgBjAHQAaQBvAG4AIABTAGgAbwB3AC0AVwBQAEYAVwBpAG4AZABvAHcAIAB7ACAAIAAgACAAIABwAGEAcgBhAG0AIAAgACAAIAAgACgAIAAgACAAIAAgACAAIAAgACAAWwBQAGEAcgBhAG0AZQB0AGUAcgAoAE0AYQBuAGQAYQB0AG8AcgB5ACkAXQAgACAAIAAgACAAIAAgACAAIABbAFcAaQBuAGQAbwB3AHMALgBXAGkAbgBkAG8AdwBdACAAIAAgACAAIAAgACAAIAAgACQAVwBpAG4AZABvAHcAIAAgACAAIAAgACkAIAAgACAAIAAgACAAIAAgACAAIAAkAHIAZQBzAHUAbAB0ACAAPQAgACQAbgB1AGwAbAAgACAAIAAgACAAJABuAHUAbABsACAAPQAgACQAdwBpAG4AZABvAHcALgBEAGkAcwBwAGEAdABjAGgAZQByAC4ASQBuAHYAbwBrAGUAQQBzAHkAbgBjAHsAIAAgACAAIAAgACAAIAAgACAAJAByAGUAcwB1AGwAdAAgAD0AIAAkAHcAaQBuAGQAbwB3AC4AUwBoAG8AdwBEAGkAYQBsAG8AZwAoACkAIAAgACAAIAAgACAAIAAgACAAUwBlAHQALQBWAGEAcgBpAGEAYgBsAGUAIAAtAE4AYQBtAGUAIAByAGUAcwB1AGwAdAAgAC0AVgBhAGwAdQBlACAAJAByAGUAcwB1AGwAdAAgAC0AUwBjAG8AcABlACAAMQAgACAAIAAgACAAfQAuAFcAYQBpAHQAKAApACAAIAAgACAAIAAkAHIAZQBzAHUAbAB0ACAAfQAgACAAJAB3AGkAbgBkAG8AdwAgAD0AIABDAG8AbgB2AGUAcgB0AC0AWABBAE0ATAB0AG8AVwBpAG4AZABvAHcAIAAtAFgAQQBNAEwAIAAkAHgAYQBtAGwAIAAgACMAZQB2AGUAbgB0AHMAIABmAHUAbgBjAHQAaQBvAG4AIABnAGUAdAAtAGYAaQByAHMAdABhAHYAYQBpAGwAYQBiAGwAZQBEAHIAaQB2AGUATABlAHQAdABlAHIAewAgACQAYQBsAGwAZAByAGkAdgBlAHMAPQBAACgAKQAgACMAYwBvAHIAcgBlAGMAdAA6ACAANgA1AC0AOQAwADsAIABrAGUAZQBwAGkAbgBnACAAYQAsAGIAIABvAHUAdAAgAHQAaAB1AHMAIAA2ADcALQA5ADAAIAA2ADcALgAuADkAMAB8AGYAbwByAGUAYQBjAGgALQBvAGIAagBlAGMAdAB7ACQAYQBsAGwAZAByAGkAdgBlAHMAKwA9AFsAYwBoAGEAcgBdACQAXwB9ACAAcgBlAHQAdQByAG4AIAAkAGEAbABsAGQAcgBpAHYAZQBzACAAfAAgAFcAaABlAHIAZQAgAHsAIAAhACgAZwBlAHQALQBwAHMAZAByAGkAdgBlACAALQBOAGEAbQBlACAAJABfACAALQBFAHIAcgBvAHIAQQBjAHQAaQBvAG4AIABTAGkAbABlAG4AdABsAHkAQwBvAG4AdABpAG4AdQBlACkAIAB9ACAAfAAgAHMAZQBsAGUAYwB0ACAALQBGAGkAcgBzAHQAIAAxACAAIwByAGUAdAB1AHIAbgAgAGcAZQB0AC0AYwBoAGkAbABkAGkAdABlAG0AIABmAHUAbgBjAHQAaQBvAG4AOgBbAGQALQB6AF0AOgAgAC0ATgBhAG0AZQAgACAAfAAgAFcAaABlAHIAZQAgAHsAIAAhACgAZwBlAHQALQB2AG8AbAB1AG0AZQAgACQAXwAuAHMAdQBiAHMAdAByAGkAbgBnACgAMAAsADEAKQAgAC0ARQByAHIAbwByAEEAYwB0AGkAbwBuACAAUwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQApACAAfQAgAHwAIABzAGUAbABlAGMAdAAgAC0ARgBpAHIAcwB0ACAAMQAgACAAcgBlAHQAdQByAG4AIAAgAH0AIAAgACQAdwBpAG4AZABvAHcALgBiAHQAbgBfAGMAbABvAHMAZQAuAGEAZABkAF8AQwBsAGkAYwBrACgAIAB7ACAAJAB3AGkAbgBkAG8AdwAuAEQAaQBhAGwAbwBnAFIAZQBzAHUAbAB0ACAAPQAgACQAZgBhAGwAcwBlACAAfQAgACkAIAAgACQAdwBpAG4AZABvAHcALgBiAHQAbgBfAGMAaABlAGMAawBOAGYAcwBTAGgAYQByAGUAcwAuAGEAZABkAF8AQwBsAGkAYwBrACgAIAB7ACAAdAByAHkAewAgACQAcwBlAHIAdgBlAHIAbgBhAG0AZQAgAD0AIAAkAHcAaQBuAGQAbwB3AC4AdAB4AHQAXwBzAGUAcgB2AGUAcgBOAGEAbQBlAC4AVABlAHgAdAAgACQAYwBpAG0AIAA9ACAATgBlAHcALQBDAGkAbQBTAGUAcwBzAGkAbwBuACAALQBDAG8AbQBwAHUAdABlAHIATgBhAG0AZQAgACQAcwBlAHIAdgBlAHIAbgBhAG0AZQAgAC0ARQByAHIAbwByAEEAYwB0AGkAbwBuACAAcwB0AG8AcAAgACQAZQB4AHAAbwByAHQAcwAgAD0AIABbAGEAcgByAGEAeQBdACgARwBlAHQALQBOAGYAcwBTAGgAYQByAGUAIAAtAEMAaQBtAFMAZQBzAHMAaQBvAG4AIAAkAGMAaQBtACAALQBFAHIAcgBvAHIAQQBjAHQAaQBvAG4AIABzAHQAbwBwAHwAIABzAGUAbABlAGMAdAAtAG8AYgBqAGUAYwB0ACAAQAB7AG4APQAnAE0AbwB1AG4AdAAnADsAZQA9AHsAJABmAGEAbABzAGUAfQB9ACwATgBhAG0AZQAsAFAAYQB0AGgALABQAHMAQwBvAG0AcAB1AHQAZQByAG4AYQBtAGUAKQAgACQAdwBpAG4AZABvAHcALgBWAGkAZQB3ADEALgBJAHQAZQBtAHMAUwBvAHUAcgBjAGUAIAA9ACAAJABlAHgAcABvAHIAdABzACAAfQBjAGEAdABjAGgAewAgACQAdwBpAG4AZABvAHcALgBWAGkAZQB3ADEALgBJAHQAZQBtAHMAUwBvAHUAcgBjAGUAIAA9ACAAJABuAHUAbABsACAAcwBlAHQALQBtAGUAcwBzAGEAZwBlACAALQBtAGUAcwBzAGEAZwBlACAAIgBOAG8AIABlAHgAcABvAHIAdABzACAAYwBvAHUAbABkACAAYgBlACAAcgBlAHQAcgBpAGUAdgBlAGQAIABmAHIAbwBtACAAcwBlAHIAdgBlAHIAYABuACQAKAAkAHMAZQByAHYAZQByAG4AYQBtAGUAKQBgAG4AQwBoAGUAYwBrACAAdABoAGUAIABzAGUAcgB2AGUAcgAgAGkAbgBmAG8AcgBtAGEAdABpAG8AbgBgAG4AVAByAHkAIABlAG4AdABlAHIAaQBuAGcAIAB0AGgAZQAgAGUAeABwAG8AcgB0ACAAcwBoAGEAcgBlACAAbgBhAG0AZQAhACIAfQAgAH0AIAApACAAIAAkAHcAaQBuAGQAbwB3AC4AYgB0AG4AXwBnAGUAdABzAGgAYQByAGUALgBhAGQAZABfAEMAbABpAGMAawAoACAAewAgACQAZQB4AHAAbwByAHQAPQAkAG4AdQBsAGwAIAAkAHcAaQBuAGQAbwB3AC4AVgBpAGUAdwAxAC4ASQB0AGUAbQBzAFsAMABdAC4ATQBvAHUAbgB0ACAAZgBvAHIAZQBhAGMAaAAgACgAJABpAHQAZQBtACAAaQBuACAAJAB3AGkAbgBkAG8AdwAuAFYAaQBlAHcAMQAuAEkAdABlAG0AcwApAHsAIABpAGYAKAAkAGkAdABlAG0ALgBNAG8AdQBuAHQAKQB7ACQAZQB4AHAAbwByAHQAIAA9ACAAJABpAHQAZQBtADsAYwBvAG4AdABpAG4AdQBlAH0AIAB9ACAAJAB3AGkAbgBkAG8AdwAuAHQAeAB0AF8AZQB4AHAAbwByAHQATgBhAG0AZQAuAFQAZQB4AHQAIAA9ACAAJABlAHgAcABvAHIAdAAuAE4AYQBtAGUAIAB9ACAAKQAgACAAJAB3AGkAbgBkAG8AdwAuAGIAdABuAF8AbQBvAHUAbgB0AEUAeABwAG8AcgB0AC4AYQBkAGQAXwBDAGwAaQBjAGsAKAAgAHsAIAAkAG0AbwB1AG4AdABEAHIAaQB2AGUAIAA9ACAAZwBlAHQALQBmAGkAcgBzAHQAYQB2AGEAaQBsAGEAYgBsAGUARAByAGkAdgBlAEwAZQB0AHQAZQByACAAJABlAHgAcABvAHIAdABwAGEAdABoACAAPQAgACIAJwBcAFwAJAAoACQAdwBpAG4AZABvAHcALgB0AHgAdABfAHMAZQByAHYAZQByAE4AYQBtAGUALgBUAGUAeAB0AC4AVAByAGkAbQAoACkAKQBcACQAKAAoACQAdwBpAG4AZABvAHcALgB0AHgAdABfAGUAeABwAG8AcgB0AE4AYQBtAGUALgBUAGUAeAB0ACkALgBUAHIAaQBtACgAKQApACcAIgAgACQAcgBlAHAAbAB5ACAAPQAgAHMAZQB0AC0AbQBlAHMAcwBhAGcAZQAgAC0AbQBlAHMAcwBhAGcAZQAgACIATQBvAHUAbgB0AGkAbgBnACAAbgBmAHMAIABlAHgAcABvAHIAdAAgACQAKAAkAGUAeABwAG8AcgB0AHAAYQB0AGgAKQAgAGEAcwAgAHYAbwBsAHUAbQBlACAAJAAoACQAbQBvAHUAbgB0AGQAcgBpAHYAZQApADoAXABgAG4ARABvACAAeQBvAHUAIAB3AGEAbgB0ACAAdABvACAAYwBvAG4AdABpAG4AZQA/ACIAIAAtAHQAaQB0AGwAZQAgACcAbgBmAHMAIABtAG8AdQBuAHQAJwAgAC0AYgB1AHQAdABvAG4AcwAgAFkAZQBzAE4AbwAgAGkAZgAoACQAcgBlAHAAbAB5ACAALQBlAHEAIAAnAE4AbwAnACkAewByAGUAdAB1AHIAbgB9ACAAJABwAG8AdwBlAHIAcwBoAGUAbABsAHAAYQB0AGgAIAA9ACAAJwBDADoAXABXAGkAbgBkAG8AdwBzAFwAUwB5AHMAdABlAG0AMwAyAFwAVwBpAG4AZABvAHcAcwBQAG8AdwBlAHIAcwBoAGUAbABsAFwAdgAxAC4AMABcAHAAbwB3AGUAcgBzAGgAZQBsAGwALgBlAHgAZQAnACAAcwB0AGEAcgB0AC0AcAByAG8AYwBlAHMAcwAgAC0ARgBpAGwAZQBQAGEAdABoACAAJABwAG8AdwBlAHIAcwBoAGUAbABsAHAAYQB0AGgAIAAtAEEAcgBnAHUAbQBlAG4AdABMAGkAcwB0ACAAIgBOAGUAdwAtAFAAUwBEAHIAaQB2AGUAIAAtAE4AYQBtAGUAIAAnACQAKAAkAG0AbwB1AG4AdABkAHIAaQB2AGUAKQAnACAALQBQAFMAUAByAG8AdgBpAGQAZQByACAARgBpAGwAZQBTAHkAcwB0AGUAbQAgAC0AUgBvAG8AdAAgACQAKAAkAGUAeABwAG8AcgB0AHAAYQB0AGgAKQAgAC0AUABlAHIAcwBpAHMAdAA7AFIAZQBhAGQALQBIAG8AcwB0ACIAIAAtAFYAZQByAGIAIAByAHUAbgBhAHMAIAAtAFcAYQBpAHQAIAAjAC0AVwBpAG4AZABvAHcAUwB0AHkAbABlACAASABpAGQAZABlAG4AIAB0AHIAeQB7ACAAaQBuAHYAbwBrAGUALQBpAHQAZQBtACAAIgAkACgAJABtAG8AdQBuAHQARAByAGkAdgBlACkAOgBcACIAIAAtAEUAcgByAG8AcgBBAGMAdABpAG8AbgAgAHMAdABvAHAAIAB9AGMAYQB0AGMAaAB7AHMAZQB0AC0AbQBlAHMAcwBhAGcAZQAgAC0AbQBlAHMAcwBhAGcAZQAgACIARQByAHIAbwByACEAYABuACQAKAAkAF8ALgBFAHgAYwBlAHAAdABpAG8AbgAuAE0AZQBzAHMAYQBnAGUAKQAiACAALQBpAGMAbwBuACAARQByAHIAbwByAH0AIAB9ACAAKQAgACAAIwAkAHcAaQBuAGQAbwB3AC4AVgBpAGUAdwAxAC4ASQB0AGUAbQBzAFMAbwB1AHIAYwBlACAAPQAgAEAAKABHAGUAdAAtAFAAcgBvAGMAZQBzAHMAIAB8ACAAVwBoAGUAcgBlAC0ATwBiAGoAZQBjAHQAIAB7ACAAJABfAC4ATQBhAGkAbgBXAGkAbgBkAG8AdwBUAGkAdABsAGUAIAB9ACkAIAAgACQAbgB1AGwAbAAgAD0AIABTAGgAbwB3AC0AVwBQAEYAVwBpAG4AZABvAHcAIAAtAFcAaQBuAGQAbwB3ACAAJAB3AGkAbgBkAG8AdwAgADwAIwAgACQAYwBpAG0AIAA9ACAATgBlAHcALQBDAGkAbQBTAGUAcwBzAGkAbwBuACAALQBDAG8AbQBwAHUAdABlAHIATgBhAG0AZQAgACcAMQAwAC4ANAAwAC4AMQAyAC4AMgAxACcAIABHAGUAdAAtAE4AZgBzAFMAaABhAHIAZQAgAC0AQwBpAG0AUwBlAHMAcwBpAG8AbgAgACQAYwBpAG0AIAB8ACAAcwBlAGwAZQBjAHQALQBvAGIAagBlAGMAdAAgAE4AYQBtAGUALABQAGEAdABoACwAUABzAEMAbwBtAHAAdQB0AGUAcgBuAGEAbQBlACAAZwBlAHQALQBjAGgAaQBsAGQAaQB0AGUAbQAgAGYAdQBuAGMAdABpAG8AbgA6AFsAZAAtAHoAXQAgAC0ATgBhAG0AZQAgACAAfAAgAD8AewAgACEAKAB0AGUAcwB0AC0AcABhAHQAaAAgACQAXwApACAAfQAgAHwAIABzAGUAbABlAGMAdAAgAC0ARgBpAHIAcwB0ACAAMQAgACMAPgA='
return $x

}

#endregion

#region Code Behind
function Convert-XAMLtoWindow
{
  param
  (
    [Parameter(Mandatory=$true)]
    [string]
    $XAML
  )
  
  Add-Type -AssemblyName PresentationFramework
  
  $reader = [XML.XMLReader]::Create([IO.StringReader]$XAML)
  $result = [Windows.Markup.XAMLReader]::Load($reader)
  $reader.Close()
  $reader = [XML.XMLReader]::Create([IO.StringReader]$XAML)
  while ($reader.Read())
  {
      $name=$reader.GetAttribute('Name')
      if (!$name) { $name=$reader.GetAttribute('x:Name') }
      if($name)
      {$result | Add-Member NoteProperty -Name $name -Value $result.FindName($name) -Force}
  }
  $reader.Close()
  $result
}

function Show-WPFWindow
{
  param
  (
    [Parameter(Mandatory=$true)]
    [Windows.Window]
    $Window
  )
  
  $result = $null
  $null = $window.Dispatcher.InvokeAsync{
    $result = $window.ShowDialog()
    Set-Variable -Name result -Value $result -Scope 1
  }.Wait()
  $result
}
#endregion Code Behind

function get-nfsstatus{
$nfsall = get-windowsfeature -name *nfs* 
$nfsstatus = $nfsall | select-object -Property Name,displayname,@{n='CurrentState';e={$_.installed}},Installed | sort-object -Property Name
return $nfsstatus
}

function get-installstate{
param($state)

if($state){return 'Install'}else{return 'Remove'}

}

#region Convert XAML to Window
$window = Convert-XAMLtoWindow -XAML $xaml 
#endregion

#region Define Event Handlers


$window.btn_Exit.add_Click(
  {
    $window.DialogResult = $false
  }
)

$window.add_Loaded(
{

$window.view_Feature.ItemsSource = get-nfsstatus
[array]$updatedshare = [array]((Get-NfsShare -ErrorAction SilentlyContinue) | select-object -Property @{n='Remove';e={$false}},Name,Path,IsOnline,NetworkName,UnmappedUserAccess) | Sort-Object -Property Name
$window.view_Export.ItemsSource = $updatedshare
$window.view_Share.ItemsSource = [array](Get-WmiObject -Class Win32_MappedLogicalDisk | select @{n='Remove';e={$false}},Name, ProviderName,filesystem)
}
)

$window.btn_AddWindowsFeatures.add_Click(
{
$nfsstatus=get-nfsstatus

$requirednfsstate = @()
for($i = 0; $i -lt $nfsstatus.count; $i++){
$requirednfsstate += [pscustomobject]@{name=$window.view_Feature.Items[$i].Name;CurrentState=$window.view_Feature.Items[$i].CurrentState;installed=$window.view_Feature.Items[$i].Installed}
}

$actions = @()
foreach($item in $requirednfsstate){
if($item.currentstate -ne $item.installed){$actions +=$item;}
}
if($actions.count -lt 1){set-message -message 'Nothing to do'; return}
$xmessage = (($actions | ft -Property @{n='operation';e={get-installstate -state ($_.installed)}},Name -HideTableHeaders -AutoSize) | out-string).Trim()

$reply = set-message -message "The following action(s) will be performed:`n$($xmessage)`nDo you want to continue?" -title 'Windows nfs feature selection' -buttons YesNo
if($reply -eq 'No'){return}
foreach ($action in $actions){
try{
if($action.installed){
#$result = Install-WindowsFeature -Name "$($action.name)" -IncludeAllSubFeature -IncludeManagementTools -erroraction Stop

start-process -FilePath C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe -ArgumentList "Install-WindowsFeature -Name $($action.name) -IncludeAllSubFeature -IncludeManagementTools -erroraction silentlycontinue" -Verb runas -Wait
$featurelist="$(((get-nfsstatus| where {$_.currentstate -eq $true}|select-object -property Displayname| ft -HideTableHeaders) | out-string).Trim())"
if(!($featurelist)){$featurelist = '***None***'}
set-message -message "Installed nfs Features:`n$featurelist"
}
else{
start-process -FilePath C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe -ArgumentList "Uninstall-WindowsFeature -Name $($action.name) -IncludeManagementTools -erroraction silentlycontinue"  -Verb runas -Wait
$featurelist="$(((get-nfsstatus| where {$_.currentstate -eq $true}|select-object -property Displayname| ft -HideTableHeaders) | out-string).Trim())"
if(!($featurelist)){$featurelist = '***None***'}
set-message -message "Installed nfs Features:`n$featurelist"
}
}catch{set-message -message "Error ($_.message)"; }
}
$window.view_Feature.ItemsSource = get-nfsstatus
return
}
)

$window.btn_AddNfsExport.add_Click(
{
$sharepath = get-folderName -initialdirectory (get-location) -title "Select folder to export as nfs"
if(!($sharepath)){return}
$reply = set-message "A new nfs export will be created. The path is:`n$($sharepath)`nDo you want to continue?" -title "New nfs export" -buttons YesNo
if($reply -eq 'No'){return}
$sharename = split-path $sharepath -Leaf

New-NfsShare -Name $sharename -Path $sharepath -AllowRootAccess $true -Permission readwrite -Authentication all -Confirm:$false
#$updatedShares = ([array]((Get-NfsShare) | select-object -Property @{n='remove';e={$false}},Name,IsOnline,Path,NetworkName,UnmappedUserAccess,AnonymousAccess) | Sort-Object -Property Name)
[array]$updatedshare = [array]((Get-NfsShare) | select-object -Property @{n='Remove';e={$false}},Name,Path,IsOnline,NetworkName,UnmappedUserAccess) | Sort-Object -Property Name
$window.view_Export.ItemsSource = $updatedshare
set-message -message "Created nfs Share:`n$(($updatedShare | select-object name,path | FT -HideTableHeaders | out-string).trim())"
#$window.view_Export.ItemsSource = $updatedShares


}
)

$window.btn_RemoveNfsExport.add_Click(
{
#[array]$exports = $window.view_Export.SelectedItems | select-object -property name,path
$exports=@()

foreach ($item in $window.view_Export.Items){
if($item.Remove){$exports += $item}
}

if($exports.count -lt 1){set-message "Nothing to do";return}

$reply = set-message -message "The following exports will be removed:`n$(($exports| FT -Property name,path -HideTableHeaders  | out-string).trim())`nDo you want to continue?" -title "nfs Exports Removal" -buttons YesNo
if($reply -eq 'No'){return}
foreach($export in $exports){
$result = Remove-NfsShare -Path $export.path -Confirm:$false
}
#[System.Collections.ArrayList]$updatedshare=[array]((Get-NfsShare) | select-object -Property @{n='Remove';e={$false}},Name,IsOnline,Path,NetworkName,UnmappedUserAccess,AnonymousAccess) | sort-object -Property name
[array]$updatedshare = [array]((Get-NfsShare) | select-object -Property @{n='Remove';e={$false}},Name,Path,IsOnline,NetworkName,UnmappedUserAccess) | Sort-Object -Property Name
$window.view_Export.ItemsSource = $updatedshare

}
)

$window.btn_addNfsShare.add_Click(
{
$powershellpath = 'C:\Windows\System32\WindowsPowershell\v1.0\powershell.exe'
start-process -FilePath $powershellpath -ArgumentList "c:\temp\MountNfsExport.ps1" -verb runas -WindowStyle Hidden -Wait
$window.view_Share.ItemsSource = [array](Get-WmiObject -Class Win32_MappedLogicalDisk | select @{n='Remove';e={$false}},Name, ProviderName,filesystem)

}
)

$window.btn_removeNfsShare.add_Click(
{
$shares=@()
foreach ($item in $window.view_Share.Items){
if($item.Remove){$shares += $item}
}
if($shares.count -lt 1){set-message "Nothing to do";return}
$reply = set-message -message "The following shares will be removed:`n$(($shares | FT -Property name,providername -HideTableHeaders  | out-string).trim())`nDo you want to continue?" -title "nfs Exports Removal" -buttons YesNo
if($reply -eq 'No'){return}

foreach($xshare in $shares){
$Drive=$null
$wmiprovider = ($xshare.providername).replace('\','\\')
[array]$Drive = Get-WmiObject -Class Win32_mappedLogicalDisk -filter "ProviderName='$($wmiprovider)'"
start-process -FilePath C:\windows\system32\cmd.exe -ArgumentList " /C net use $($Drive.Name[0]): /delete /y" -Verb runas -Wait -WindowStyle Hidden
}
$window.view_Share.ItemsSource = [array](Get-WmiObject -Class Win32_MappedLogicalDisk | select @{n='Remove';e={$false}},Name, ProviderName,filesystem)


}
)

#endregion Event Handlers

#region Manipulate Window Content

#$null = $window.TxtName.Focus()
#endregion

# Show Window
$result = Show-WPFWindow -Window $window

#region Process results
if ($result -eq $true)
{

}
else
{
  Write-Warning 'User aborted dialog.'
}
#endregion Process results