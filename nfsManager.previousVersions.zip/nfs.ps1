﻿#region XAML window definition
# Right-click XAML and choose WPF/Edit... to edit WPF Design
# in your favorite WPF editing tool
$xaml = @'
<Window
   xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
   xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
   MinWidth="200"
   Width ="400"
   SizeToContent="WidthAndHeight"
   Title="Cloudistics Ad-Hoc Windows NFS Management"
   Topmost="True">
    <Grid Margin="10,40,10,10">
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="Auto"/>
            <ColumnDefinition Width="*"/>
        </Grid.ColumnDefinitions>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
        </Grid.RowDefinitions>
        <TextBlock Grid.Column="0" Grid.Row="0" Grid.ColumnSpan="2" Margin="5">Windows NFS Management Details:</TextBlock>

        <TextBlock Grid.Column="0" Grid.Row="1" Margin="5">NFS Features</TextBlock>
        <TextBlock Grid.Column="0" Grid.Row="3" Margin="5">NFS Shares</TextBlock>

        <ListView Grid.Column="1" Grid.Row="1" Name="view_Feature">
            <ListView.View>
                <GridView>
                    <GridViewColumn Width="Auto" Header="Name" DisplayMemberBinding="{Binding Name}"/>
                    <GridViewColumn Width="Auto" Header="Display Name" DisplayMemberBinding="{Binding DisplayName}"/>
                    <GridViewColumn Width="50" Header="Installed" DisplayMemberBinding="{Binding Installed}"/>
                    <GridViewColumn Header="Installed">
                        <GridViewColumn.CellTemplate>
                            <DataTemplate>
                                <CheckBox IsChecked="{Binding Installed}" />
                            </DataTemplate> 
                        </GridViewColumn.CellTemplate>
                    </GridViewColumn>
                </GridView>
            </ListView.View>
        </ListView>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Grid.Column="1" Grid.Row="2"  Margin="0,10,0,0">
            <Button Name="btn_AddWindowsFeatures" MinWidth="80" Height="22" Margin="5">Add/Remove NFS Features</Button>
        </StackPanel>

        <ListView Grid.Column="1" Grid.Row="3" Name="view_Export">
            <ListView.View>
                <GridView>
                    <GridViewColumn Width="50" Header="Name" DisplayMemberBinding="{Binding Name}"/>
                    <GridViewColumn Width="100" Header="Availability" DisplayMemberBinding="{Binding Availability}"/>
                    <GridViewColumn Width="Auto" Header="Path" DisplayMemberBinding="{Binding Path}"/>
                </GridView>
            </ListView.View>
        </ListView>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Grid.Column="1" Grid.Row="4"  Margin="0,10,0,0">
            <Button Name="btn_AddNfsExport" MinWidth="80" Height="22" Margin="5">Add NFS Export</Button>
            <Button Name="btn_RemoveNfsExport" MinWidth="80" Height="22" Margin="5">Remove NFS Export</Button>
        </StackPanel>

        <ListView Grid.Column="1" Grid.Row="5" Name="view_Share">
            <ListView.View>
                <GridView>
                    <GridViewColumn Width="50" Header="Name" DisplayMemberBinding="{Binding Name}"/>
                    <GridViewColumn Width="Auto" Header="Provider Name" DisplayMemberBinding="{Binding ProviderName}"/>
                    <GridViewColumn Width="50" Header="File System" DisplayMemberBinding="{Binding filesystem}"/>
                </GridView>
            </ListView.View>
        </ListView>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Grid.Column="1" Grid.Row="6"  Margin="0,10,0,0">
            <Button Name="btn_addNfsShare" MinWidth="80" Height="22" Margin="5">Add NFS Share</Button>
            <Button Name="btn_removeNfsShare" MinWidth="80" Height="22" Margin="5">Remove NFS Share</Button>
        </StackPanel>

        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,10,0,0" Grid.Row="7" Grid.ColumnSpan="2">
            <TextBlock Name="lbl_prerequisites" Margin="5">Prerequisites</TextBlock>
            <Button Name="btn_Exit" MinWidth="80" Height="22" Margin="5">Exit</Button>
        </StackPanel>
    </Grid>
</Window>
'@
#endregion

#region Code Behind
function Convert-XAMLtoWindow
{
  param
  (
    [Parameter(Mandatory=$true)]
    [string]
    $XAML
  )
  
  Add-Type -AssemblyName PresentationFramework
  
  $reader = [XML.XMLReader]::Create([IO.StringReader]$XAML)
  $result = [Windows.Markup.XAMLReader]::Load($reader)
  $reader.Close()
  $reader = [XML.XMLReader]::Create([IO.StringReader]$XAML)
  while ($reader.Read())
  {
      $name=$reader.GetAttribute('Name')
      if (!$name) { $name=$reader.GetAttribute('x:Name') }
      if($name)
      {$result | Add-Member NoteProperty -Name $name -Value $result.FindName($name) -Force}
  }
  $reader.Close()
  $result
}

function Show-WPFWindow
{
  param
  (
    [Parameter(Mandatory=$true)]
    [Windows.Window]
    $Window
  )
  
  $result = $null
  $null = $window.Dispatcher.InvokeAsync{
    $result = $window.ShowDialog()
    Set-Variable -Name result -Value $result -Scope 1
  }.Wait()
  $result
}
#endregion Code Behind

#region Convert XAML to Window
$window = Convert-XAMLtoWindow -XAML $xaml 
#endregion

#region Define Event Handlers
# Right-Click XAML Text and choose WPF/Attach Events to
# add more handlers
$window.btn_Exit.add_Click(
  {
    $window.DialogResult = $false
  }
)



#endregion Event Handlers

#region Manipulate Window Content

#$null = $window.TxtName.Focus()
#endregion

# Show Window
$result = Show-WPFWindow -Window $window

#region Process results
if ($result -eq $true)
{

}
else
{
  Write-Warning 'User aborted dialog.'
}
#endregion Process results